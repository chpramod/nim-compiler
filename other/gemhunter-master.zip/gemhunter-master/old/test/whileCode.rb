a = 1
b = 2
while a<20
  a += 1
  $a = 21
  if a > 15
    c = "string"
    next
  end
  c = $a
end
c = 0.7
b = $a + a

