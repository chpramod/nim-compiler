a = 1
b = 2
x = true
z = false
z = a < b && a + 2 > b
x = a <= b  || a >= b
if x then
  $a = 2
elsif z
  b = 2
else c = a+b
end

c = "Hello"
b = $a

if z then
  $a = a+1
elsif x
  $b = 2
end

