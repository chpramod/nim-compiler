#!/bin/bash
dot -Tpdf $1 > output.pdf
