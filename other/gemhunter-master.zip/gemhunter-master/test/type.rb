a = true
x = 1
x = x<<3
#a = a<<1
puts a
puts x
#puts false+true
#b = [42,20-10,+10,-10,!a,10]
c = [42,20-10,+10,-10]
#-12 && 1 ** ( !a + 123 ) - -123.32 + 12
#@@ans = 1
n = nil
#n = 1
#puts n
y = 5/4
puts y
#s = 3 && 4
#puts s
t = 3 & 4
puts t
t = 5 & 4
puts t
puts "nil example"
puts a
y = 0b0101
puts y
y = 0o51
puts y
y = 0x33
puts y
#super()