#!/bin/bash
./irgen.py ../test/exprCode.rb
./irgen.py ../test/untilCode.rb
./irgen.py ../test/whileCode.rb
./irgen.py ../test/ifCode.rb
./irgen.py ../test/classCode.rb
./irgen.py ../test/methodCode.rb
./irgen.py ../test/recursionCode.rb
./irgen.py ../test/arrayCode.rb
./irgen.py ../test/tryCode.rb
