var x = 2;
var y = 3;
var z = x*y;
console.log(z);
console.log(z%3);
console.log(z/3);
