
// Simple addition
var z::num;
var x = 1;
var y = 2;
z = x + y;

console.log(z);
