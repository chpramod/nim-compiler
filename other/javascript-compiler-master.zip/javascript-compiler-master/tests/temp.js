function temp() {
    var x;
    x = 1;
    x = 1;
    x = 1;
    x = 1;
}

temp();

