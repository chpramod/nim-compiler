
var k = 1;
if ( k > 1 ) {
    console.log("here")
}
