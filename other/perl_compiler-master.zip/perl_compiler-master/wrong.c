{'root': {
	'child2': {
		'parent': 'root1', 
		'width': 12, 
		'child45': {
			'parent': 'child2', 
			'width': 0, 
			'scope_depth': 2, 
			'returntype': 'UNDEFINED', 
			'scope': 'child45', 
			'type': 'FUNCTION'
		}, 
		'scope_depth': 1, 
		'returntype': 'NUMBER', 
		'scope': 'child2', 
		'type': 'FUNCTION'
	}, 
	'$ret3': {
		'returntype': 'UNDEFINED', 
		'scope': 'root1', 
		'type': 'NUMBER', 
		'width': 4
	}, 
	'parent': 'root1', 
	'$ret2': {
		'returntype': 'UNDEFINED', 
		'scope': 'root1', 
		'type': 'UNDEFINED', 
		'width': 0
	}, 
	'child': {
		'returntype': 'UNDEFINED', 
		'scope': 'root1', 
		'scope_depth': 2, 
		'type': 'FUNCTION', 
		'width': 8
	}, 
	'$b': {
		'returntype': 'UNDEFINED', 
		'scope': 'root1', 
		'type': 'RES_STRING', 
		'width': 8
	}, 
	'$ret': {
		'returntype': 'UNDEFINED', 
		'scope': 'root1', 
		'type': 'RES_STRING', 
		'width': 8
	}, 
	'$a': {
		'returntype': 'UNDEFINED', 
		'scope': 'root1', 
		'type': 'NUMBER', 
		'width': 4
	}, 
	'width': 44, 
	'child45': {
		'returntype': 'UNDEFINED', 
		'scope': 'root1', 
		'scope_depth': 2, 
		'type': 'FUNCTION', 
		'width': 8
	}, 
	'parent1': {
		'parent': 'root1', 
		'child': {
			'parent': 'parent1', 
			'width': 4, 
			'scope_depth': 2, 
			'returntype': 'RES_STRING', 
			'scope': 'child', 
			'type': 'FUNCTION'
		}, 
		'$a': {
			'returntype': 'UNDEFINED', 
			'scope': 'parent1', 
			'type': 'NUMBER', 
			'width': 4
		}, 
		'width': 24, 
		'scope_depth': 1, 
		'returntype': 'RES_STRING', 
		'scope': 'parent1', 
		'type': 'FUNCTION'
	}, 
	'scope_depth': 0, 
	'returntype': 'UNDEFINED', 
	'scope': 'root1', 
	'$tmp': {
		'returntype': 'UNDEFINED', 
		'scope': 'root1', 
		'type': 'NUMBER', 
		'width': 4
	}, 
	'type': 'FUNCTION'
}}
