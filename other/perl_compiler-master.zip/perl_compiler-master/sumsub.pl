$a = 10;
$b = 20;

$sum = $a / $b;
print "$sum";

