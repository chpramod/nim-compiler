$a="nikhil";
$b="tanana";
$c=$a.$b;
print $c;