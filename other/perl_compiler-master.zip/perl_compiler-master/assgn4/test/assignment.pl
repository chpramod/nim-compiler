my $a, $b;
$a = "sara";
$a=3;
print $a;
print "strin avikalp\n";