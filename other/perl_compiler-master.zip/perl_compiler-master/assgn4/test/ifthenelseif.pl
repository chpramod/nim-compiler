#!/usr/bin/perl

# SOME VARIABLES
$x = 9;
$y = 7;

# TESTING...ONE, TWO...TESTING
if ($x > 7) {
	print $x;
	print " is equal to 7!";
	print "\n";
}
# # SOME VARIABLES
$name = "Sarah";
$x = 5;

# # IF/ELSE STATEMENTS
if ($x > 10) {
	print $x;
	print " is greater than 10!";
} else {
	print $x;
	print " is not greater than 10!";
	print "ABSE";
}
print "\n";