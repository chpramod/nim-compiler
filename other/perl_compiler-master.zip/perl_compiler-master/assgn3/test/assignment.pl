my $a, $b;
$a = 1;
$a+=3;
print $a;
