$a=5+12;
print $a;


























