@array_name = (10, 11, 12);
%hash_name = ('Avikalp', 12178, 'Nikhil', 9999, 'Deepak', 420);

$a = 0x2;
$array_name[2] = 2;
$hash_name{'Avikalp'} = $hash_name{'Deepak'};