#!/usr/bin/perl

# SOME VARIABLES
$x = 9;
$y = 7;

# TESTING...ONE, TWO...TESTING
# if ($x > 7) {
# 	print "$x is equal to 7!";
# 	print "\n";
# }
# $x=3;
# print $x;
# if (($x == 7) || ($y == 7)) {
# 	print '$x or $y is equal to 7!';
# 	print "\n";
# }
# if (($x == 7) && ($y == 7)) {
# 	print '$x and $y are equal to 7!';
# 	print "\n";
# }

# # SOME VARIABLES
# $name = "Sarah";
# $x = 5;

# # IF/ELSE STATEMENTS
if ($x > 10) {
	print "$x is greater than 10!";
} else {
	print "$x is not greater than 10!";
	print "ABSE";
}
print "\n";

# STRINGS ARE A LITTLE DIFFERENT
# if ($name eq "Sarah") {
# 	print "Hello, $name!\n";
# } else {
# 	print "You are not $name!\n";
# }
