sub add {
    my @list = @_;
    $size = @list;
    local $sum;
    for($i=0; $i<$size; $i=$i+1){
        $sum = $sum + $list[$i];
    }
    return $sum;
    my $new1 = 100000;
    $new2 = 123456;
}

sub justPrint{
    print $new;
    print "\n".$new1;
}

print "Enter the numbers to be added:-\n";
$a = 1;
$b = ();
$ans = add($a, $b);
print "Testing somethin ".$new2."\n";
print $a." + ".$b." = ".$ans."\n";
$a = (1<2);
$ans = ($a == 1);
print $ans."\n";
$a = 'avikalp';
print $a."\n";
$b =1;
$a,$b = (1,2);
print $a." ".$b." \n";
print ($a, $b);
print '-'x80;
print "\n";
print ($a);
$new = 23;
local $new1 = 1000;
justPrint();
