#!/usr/bin/perl
{
$a=10;

#I am just writing some comment
@b=(1,2,3);
	print ("er\tror\n")
print ('er\tror\n')
19a 
$a = $b * $c;
if ($a>1 or $b) {
	# body...
}
}






