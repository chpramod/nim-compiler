$a="nikhil";
$b="tanana";
$c=$a.$b;
$c.=$a;
print $c;