int main()
{
	int a=10;
	int b=19;
	if (1<=a && b>4)
	{
		a=a+1;
	}
	return 0;
}

