def term(term):
	print term
term('qwerty')
