$a = 10;
$b = 12;
if(($a==1) || ($b=12))
{
    $a ++;
    print $a;
    #$c = <>;
    #print chomp($c);
    #($c > 10) ? print $c : print (10-$c)."\n" ;
}
