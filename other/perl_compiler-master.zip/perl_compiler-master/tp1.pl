@a+=10;
while(1)
{
	prnt ("term");
	last;
}
for($a=0;$a<10;$a++)

{
	print ("$a");
}
switch ($val) {
		case (1)		{ print ("number 1") }
		case (%hash)	{ print ("entry in hash") }
		else		{ print "previous case not true" }
	}
 sub parg {
     my ($a, $b, $c)= @_;
     next ;
     last ;
}













