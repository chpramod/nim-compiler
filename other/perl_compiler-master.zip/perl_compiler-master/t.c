int main()
{
  int a= 10;
  int b=20;
 int c;
c=a+b; 
  return 0;
}
