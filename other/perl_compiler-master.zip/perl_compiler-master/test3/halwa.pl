$a = 1;
$b = $a + 1;
if ($a>=0){
	if($b <= -3){
		pnt "Hello";
	}
}
else{
	print $b++;
}